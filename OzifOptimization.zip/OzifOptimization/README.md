                                        ***Ozif Optimizer***
                                        
  
  Current ver : 0.0.1
  Date uploaded 3/14/2022
  Maker: Avgyarn
  
            Description: A magisk module aimed to help improve the performance of low end android phones. It also makes your phone a Pixel 5 for Apex legends
            
            Features: Ram optimization, gpu optimization, wifi/data optimization, Screen optimizations, gaming optimization.
            
            
            Please note. That when you install this module you basicly voided your warranty i have 0 control over if your device broke so im warning you, it may or may not break your device.
            
            Upcoming releases : Ozif Lite - No set release date
            Updates: to update simply delete the current Ozif and install the new one!.
